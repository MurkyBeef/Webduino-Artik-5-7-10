#!/bin/sh

#This is the shell script to test the Artik will run all scripts in this package properly

echo "Hello World"

