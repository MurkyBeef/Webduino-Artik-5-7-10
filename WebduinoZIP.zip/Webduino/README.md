# Webduino Package

#Webduino is designed for use with the Samsung Artik 520 and similar devices. 
#Webduino streamlines the proccesses preformed by the Artik 5 for setup and other services.
#This project is designed as a framework to make advanced programming with the Artik easier

