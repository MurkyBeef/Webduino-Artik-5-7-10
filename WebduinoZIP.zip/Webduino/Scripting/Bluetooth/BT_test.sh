#!/bin/sh

$ val=(ping 8.8.8.8)
echo $val
