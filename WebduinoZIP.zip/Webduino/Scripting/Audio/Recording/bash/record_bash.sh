#!/bin/bash
set -x
TIME=$(read -r 1<record_config.txt)
PATH=$(read -r 2<record_config.txt)
arecord --duration=$TIME $PATH
echo 'Recording stored at $PATH'