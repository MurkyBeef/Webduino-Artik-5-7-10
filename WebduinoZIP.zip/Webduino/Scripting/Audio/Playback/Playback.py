import pyaudio
import wave
import sys
#import xml.etree.ElementTree as ET
#tree = ET.parse('audio.xml')
#root = tree.getRoot()

#def findXML( category, tag ):
#	for category in root.findall(category):
#		val = category.find(tag).text
#	return val

# length of data to read.
CHUNK = 1024

# validation. If a wave file hasn't been specified, exit.
if len(sys.argv) < 2:
    print "Plays a wave file.\n\n" +\
          "Usage: %s filename.wav" % sys.argv[0]
    sys.exit(-1)

# open the file for reading.
waveFile = wave.open(sys.argv[1], 'rb')

# create an audio object
audio = pyaudio.PyAudio()

# open stream
stream = audio.open(format = audio.get_format_from_width(waveFile.getsampwidth()),
    channels = waveFile.getnchannels(),
    rate = waveFile.getframerate(),
    output = True)

# read data (based on the chunk size)
data = waveFile.readframes(CHUNK)

# play stream)
while data != '':
    stream.write(data)
    data = waveFile.readframes(CHUNK)

# cleanup stuff.
stream.close()
audio.terminate()