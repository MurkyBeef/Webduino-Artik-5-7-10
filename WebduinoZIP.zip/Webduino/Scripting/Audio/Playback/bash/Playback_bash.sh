#!/bin/bash
set -x
PATH=$(read -r 1<playback_config.txt)
aplay $PATH
