#!/bin/sh

$ path=$(xmlstarlet sel -t -m '//Path[1]' -v . -n <playback.xml)

aplay $path
