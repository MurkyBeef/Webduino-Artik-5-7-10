#!/bin/bash/
set -x
bluetoothctl
agent on
default-agent
scan on

