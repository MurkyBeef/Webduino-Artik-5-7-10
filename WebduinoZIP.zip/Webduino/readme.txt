   ___       __  _ __     __   _               
  / _ | ____/ /_(_) /__  / /  (_)__  __ ____ __
 / __ |/ __/ __/ /  '_/ / /__/ / _ \/ // /\ \ /
/_/ |_/_/  \__/_/_/\_\ /____/_/_//_/\_,_//_\_\

Automation of Samsung Artik 5 Development Platform

Included:

-Shell Scripts
-Arduino Scripts
-Python Scripts
-XML Managment
-WIP LCD Serial monitor

-Supported Features:

-Wifi:
	-Wifi Access Point
	-Wifi Client
	-Wifi P2P Connection

-Audio:
	-Record
	-Playback
	-Tuning [WIP as of 5/8/2017] 

Future Features:

